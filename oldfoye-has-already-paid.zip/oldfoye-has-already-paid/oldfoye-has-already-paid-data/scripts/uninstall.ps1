﻿chcp 65001 | Out-Null

$OutputEncoding = [System.Text.Encoding]::UTF8
[Console]::OutputEncoding = [System.Text.Encoding]::UTF8
[Console]::InputEncoding = [System.Text.Encoding]::UTF8

Clear-Host

$yonghu_lu = [Environment]::GetEnvironmentVariable("USERPROFILE")
$gonggong_lu = [Environment]::GetEnvironmentVariable("PUBLIC")
$bendi_jb     = Join-Path -Path $yonghu_lu -ChildPath "AppData\Local\JetBrains\"
$manyou_jb    = Join-Path -Path $yonghu_lu -ChildPath "AppData\Roaming\JetBrains\"
$gongzuo_lu   = "$gonggong_lu\.jb_run\"

$chanpin_lie = @(
    @{ ming = "idea" }, @{ ming = "clion" }, @{ ming = "phpstorm" },
    @{ ming = "goland" }, @{ ming = "pycharm" }, @{ ming = "webstorm" },
    @{ ming = "rider" }, @{ ming = "datagrip" }, @{ ming = "rubymine" },
    @{ ming = "appcode" }, @{ ming = "dataspell" }, @{ ming = "rustrover" }
)

function Han_Hua([string]$xiaoxi, [string]$jibie = "INFO")
{
    $shijian = Get-Date -Format "yyyy-MM-dd HH:mm:ss"
    switch ($jibie)
    {
        "SUCCESS" { $yanse = "Green" }
        "WARNING" { $yanse = "Yellow" }
        "ERROR"   { $yanse = "Red" }
        default   { $yanse = "White" }
    }
    Write-Host "[$shijian][$jibie] $xiaoxi" -ForegroundColor $yanse
}

Han_Hua "老佛爷要收回授权了……" "WARNING"

# -- 管理员权限 --
if (-not ([Security.Principal.WindowsPrincipal][Security.Principal.WindowsIdentity]::GetCurrent()).IsInRole([Security.Principal.WindowsBuiltInRole]"Administrator"))
{
    Han_Hua "需要管理员权限，正在提权..." "WARNING"
    Start-Process powershell.exe -ArgumentList "-NoProfile -ExecutionPolicy Bypass -File `"$PSCommandPath`"" -Verb RunAs
    exit 0
}

# -- 关闭 IDE 提醒 --
Han_Hua "请确保所有 JetBrains IDE 已关闭！" "WARNING"
Write-Host "按回车开始卸载..." -ForegroundColor Yellow
$null = Read-Host

$moshi = "^-javaagent:.*[/\\]*\.jar.*"
$zhengze = [regex]::new($moshi, [System.Text.RegularExpressions.RegexOptions]::IgnoreCase -bor [System.Text.RegularExpressions.RegexOptions]::Compiled)
$zongshu = 0

# -- 清理 vmoptions + 删除 key --
Han_Hua "开始清理 JetBrains 产品配置..." "INFO"

try {
    if (Test-Path -Path $bendi_jb)
    {
        $mulu_lie = Get-ChildItem -Path $bendi_jb -Directory -ErrorAction SilentlyContinue
        foreach ($mulu in $mulu_lie)
        {
            $home_wenjian = Join-Path -Path $mulu.FullName ".home"
            if (-not (Test-Path -Path $home_wenjian)) { continue }

            $zhenshi_lu = Get-Content -Path $home_wenjian -Encoding UTF8 -ErrorAction SilentlyContinue
            if (-not $zhenshi_lu -or -not (Test-Path -Path $zhenshi_lu)) { continue }

            $bin_lu = Join-Path -Path $zhenshi_lu "bin"
            if (-not (Test-Path -Path $bin_lu)) { continue }

            # 清理 vmoptions
            $vm_wenjian_lie = Get-ChildItem -Path $bin_lu -Filter "*.vmoptions" -Recurse -ErrorAction SilentlyContinue
            foreach ($vm in $vm_wenjian_lie)
            {
                $hang_lie = Get-Content -Path $vm.FullName -Encoding UTF8 -ErrorAction SilentlyContinue
                if ($hang_lie)
                {
                    $guolv = $hang_lie | Where-Object { -not $zhengze.IsMatch($_) }
                    Set-Content -Path $vm.FullName -Value $guolv -Force -ErrorAction SilentlyContinue
                    Han_Hua "清理 vmoptions: $($vm.FullName)" "INFO"
                    $zongshu++
                }
            }

            # 删除 roaming 下的 key 文件
            $quanming = $mulu.Name
            foreach ($chanpin in $chanpin_lie)
            {
                if ($quanming.ToLower().Contains($chanpin.ming))
                {
                    $miyao_lu = Join-Path -Path $manyou_jb -ChildPath $quanming
                    if (Test-Path -Path $miyao_lu)
                    {
                        $miyao_wenjian = Join-Path -Path $miyao_lu "$($chanpin.ming).key"
                        if (Test-Path -Path $miyao_wenjian)
                        {
                            Remove-Item -Path $miyao_wenjian -Force -ErrorAction SilentlyContinue
                            Han_Hua "删除 key: $miyao_wenjian" "SUCCESS"
                            $zongshu++
                        }
                    }
                    break
                }
            }
        }
    }

    # -- 清除环境变量 --
    foreach ($chanpin in $chanpin_lie)
    {
        $daxie_jian = "$($chanpin.ming.ToUpper())_VM_OPTIONS"
        foreach ($zuoyongyu in @("User", "Machine"))
        {
            $zhi = [Environment]::GetEnvironmentVariable($daxie_jian, $zuoyongyu)
            if ($zhi)
            {
                [Environment]::SetEnvironmentVariable($daxie_jian, $null, $zuoyongyu)
                Han_Hua "清除环境变量 [$zuoyongyu]: $daxie_jian" "SUCCESS"
                $zongshu++
            }
        }
    }

    # -- 删除工作目录 --
    if (Test-Path -Path $gongzuo_lu)
    {
        Remove-Item -Path $gongzuo_lu -Recurse -Force -ErrorAction SilentlyContinue
        Han_Hua "删除工作目录: $gongzuo_lu" "SUCCESS"
        $zongshu++
    }
}
catch
{
    Han_Hua "卸载过程出错: $_" "ERROR"
}

Han_Hua "卸载完成，共处理 $zongshu 项。慈禧收回了她的恩赐。" "SUCCESS"
Write-Host "`n========================================" -ForegroundColor Cyan
Write-Host "  老佛爷说了：下次再来啊！" -ForegroundColor Green
Write-Host "========================================`n" -ForegroundColor Cyan
$null = Read-Host
