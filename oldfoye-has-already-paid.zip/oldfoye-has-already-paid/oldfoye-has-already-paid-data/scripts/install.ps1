﻿chcp 65001 | Out-Null

$OutputEncoding = [System.Text.Encoding]::UTF8
[Console]::OutputEncoding = [System.Text.Encoding]::UTF8
[Console]::InputEncoding = [System.Text.Encoding]::UTF8

Clear-Host

$script:tiaoshi_kai = $false

try {
    $xitong_yuyan = (Get-UICulture).Name
    if ($xitong_yuyan -like "zh*" -or $xitong_yuyan -like "zh-*") {
        $script:yuyan = "zh"
    } else {
        $script:yuyan = "en"
    }
} catch {
    $script:yuyan = "zh"
}

function Kan_Hua
{
    param(
        [string]$jian
    )

    $hua_biao = @{
        "processing_env_vars" = @{
            "zh" = "处理 {0} 环境变量"
            "en" = "Processing {0} environment variables"
        }
        "checking_env" = @{
            "zh" = "检查 [{0}]: {1} = '{2}'"
            "en" = "Checking [{0}]: {1} = '{2}'"
        }
        "deleting_env" = @{
            "zh" = "删除 [{0}]: {1}"
            "en" = "Deleting [{0}]: {1}"
        }
        "admin_request" = @{
            "zh" = "即将申请管理员权限运行，按回车继续..."
            "en" = "Administrator privileges will be requested to run, press Enter to continue..."
        }
        "close_products" = @{
            "zh" = "`n请确保所有 JetBrains 软件已关闭，按回车继续..."
            "en" = "`nPlease make sure all JetBrains software is closed, press Enter to continue..."
        }
        "processing" = @{
            "zh" = "`n处理中，请耐心等待..."
            "en" = "`nProcessing, please wait patiently..."
        }
        "processing_configs" = @{
            "zh" = "`n开始处理配置..."
            "en" = "`nStarting to process configurations..."
        }
        "not_found_dir" = @{
            "zh" = "未找到 {0} 目录!"
            "en" = "Directory not found: {0}!"
        }
        "processing_product" = @{
            "zh" = "`n处理: {0}"
            "en" = "`nProcessing: {0}"
        }
        "not_found_home" = @{
            "zh" = "未找到 .home 文件: {0}"
            "en" = ".home file not found: {0}"
        }
        "path_not_exist" = @{
            "zh" = "路径不存在: {0}"
            "en" = "Path does not exist: {0}"
        }
        "not_found_bin" = @{
            "zh" = "未找到 bin 目录: {0}"
            "en" = "bin directory not found: {0}"
        }
        "config_exists_cleaning" = @{
            "zh" = "{0} 配置文件已存在，正在清理..."
            "en" = "{0} configuration file already exists, cleaning..."
        }
        "key_exists_cleaning" = @{
            "zh" = "key已存在，正在清理..."
            "en" = "Key already exists, cleaning..."
        }
        "activation_success" = @{
            "zh" = "{0} 激活成功！"
            "en" = "{0} activated successfully!"
        }
        "manual_activation_required" = @{
            "zh" = "{0} 需要手动输入激活码！"
            "en" = "{0} requires manual activation code entry!"
        }
        "download_failed" = @{
            "zh" = "下载失败: {0}"
            "en" = "Download failed: {0}"
        }
        "request_failed" = @{
            "zh" = "{0} 请求失败: {1}"
            "en" = "{0} request failed: {1}"
        }
        "file_in_use" = @{
            "zh" = "文件被占用，请先关闭所有 JetBrains IDE 后再试！"
            "en" = "File is in use, please close all JetBrains IDEs and try again!"
        }
        "processing_completed" = @{
            "zh" = "`n所有项处理完成，如需激活码，请访问网站获取！"
            "en" = "`nAll items processed. If you need an activation code, please visit the website!"
        }
        "cleaning_vmoptions" = @{
            "zh" = "清理 VMOptions: {0}"
            "en" = "Cleaning VMOptions: {0}"
        }
        "updating_vmoptions" = @{
            "zh" = "更新 VMOptions: {0}"
            "en" = "Updating VMOptions: {0}"
        }
        "processing_disabled_plugins" = @{
            "zh" = "已处理文件: {0} 中com.intellij.modules.ultimate项"
            "en" = "Processed file: {0} com.intellij.modules.ultimate item"
        }
        "file_not_exist_skip" = @{
            "zh" = "文件不存在,跳过: {0}"
            "en" = "File does not exist, skipping: {0}"
        }
        "error_processing_plugins" = @{
            "zh" = "处理禁用插件文件时出错: {0}"
            "en" = "Error processing disabled plugins file: {0}"
        }
        "processing_config" = @{
            "zh" = "处理配置: {0}, {1}, {2}"
            "en" = "Processing config: {0}, {1}, {2}"
        }
        "requesting_key" = @{
            "zh" = "请求key: {0},请求body: {1},保存地址: {2}"
            "en" = "Requesting key: {0}, request body: {1}, save path: {2}"
        }
        "writing_key" = @{
            "zh" = "写入key,激活中: {0}"
            "en" = "Writing key, activating: {0}"
        }
        "configuring_ja_netfilter" = @{
            "zh" = "配置ja-netfilter："
            "en" = "Configuring ja-netfilter:"
        }
        "file_path_empty" = @{
            "zh" = "文件路径为空，跳过处理:{0}"
            "en" = "File path is empty, skipping processing: {0}"
        }
        "found_home_file" = @{
            "zh" = "找到.home文件: {0}"
            "en" = "Found .home file: {0}"
        }
        "read_home_content" = @{
            "zh" = "读取.home文件内容: {0}"
            "en" = "Read .home file content: {0}"
        }
        "found_bin_dir" = @{
            "zh" = "找到bin目录: {0}"
            "en" = "Found bin directory: {0}"
        }
        "sha1_info" = @{
            "zh" = "{0} :SHA1: {1}"
            "en" = "{0} :SHA1: {1}"
        }
        "request_fail" = @{
            "zh" = "请求失败: {0}"
            "en" = "Request failed: {0}"
        }
    }

    if ($hua_biao.ContainsKey($jian))
    {
        if ($hua_biao[$jian].ContainsKey($script:yuyan))
        {
            return $hua_biao[$jian][$script:yuyan]
        }
    }

    return $jian
}

function Han_Hua
{
    param(
        [Parameter(Mandatory = $true)]
        [string]$xiaoxi,

        [ValidateSet("INFO", "DEBUG", "WARNING", "ERROR", "SUCCESS")]
        [string]$jibie = "INFO"
    )

    if ($jibie -eq "DEBUG" -and -not $script:tiaoshi_kai)
    {
        return
    }

    switch ($jibie)
    {
        "INFO" {
            $yanse = "White"
        }
        "DEBUG" {
            $yanse = "DarkGray"
        }
        "WARNING" {
            $yanse = "Yellow"
        }
        "ERROR" {
            $yanse = "Red"
        }
        "SUCCESS" {
            $yanse = "Green"
        }
    }

    $shijian = Get-Date -Format "yyyy-MM-dd HH:mm:ss"

    if ($xiaoxi.StartsWith("`n"))
    {
        $xiaoxi = $xiaoxi.Substring(1)
        Write-Host "`n[$shijian][$jibie] $xiaoxi" -ForegroundColor $yanse
    }
    else
    {
        Write-Host "[$shijian][$jibie] $xiaoxi" -ForegroundColor $yanse
    }
}

function Di_Gu([string]$xiaoxi)
{
    $canshu = $args
    if ($canshu.Count -gt 0)
    {
        try
        {
            $xiaoxi = $xiaoxi -f $canshu
        }
        catch
        {
        }
    }
    Han_Hua -xiaoxi $xiaoxi -jibie "DEBUG"
}
function Rang([string]$xiaoxi)
{
    $canshu = $args
    if ($canshu.Count -gt 0)
    {
        try
        {
            $xiaoxi = $xiaoxi -f $canshu
        }
        catch
        {
        }
    }
    Han_Hua -xiaoxi $xiaoxi -jibie "WARNING"
}
function Ma([string]$xiaoxi)
{
    $canshu = $args
    if ($canshu.Count -gt 0)
    {
        try
        {
            $xiaoxi = $xiaoxi -f $canshu
        }
        catch
        {
        }
    }
    Han_Hua -xiaoxi $xiaoxi -jibie "ERROR"
}
function Hao([string]$xiaoxi)
{
    $canshu = $args
    if ($canshu.Count -gt 0)
    {
        try
        {
            $xiaoxi = $xiaoxi -f $canshu
        }
        catch
        {
        }
    }
    Han_Hua -xiaoxi $xiaoxi -jibie "SUCCESS"
}

function Shan_Ren
{
    $null = Read-Host
    exit 1
}

function Hua_Tiao([string]$xiaoxi, [string]$jindu_tiao, [double]$baifenbi, [string]$yanse = "White")
{
    $shuchu = "{0} {1} {2}%" -f $xiaoxi.PadRight(10), $jindu_tiao, $baifenbi.ToString("F2")
    [Console]::ForegroundColor = $yanse
    [Console]::Write("`r" + $shuchu.PadRight(100))
    [Console]::ResetColor()
}

function Liang_Paizi
{
    Write-Host @"

  ______ ______  ______  ______
 |  ____|  __ \|  ____|  ____|
 | |__  | |__) | |__   | |__
 |  __| |  _  /|  __|  |  __|
 | |    | | \ \| |____ | |____
 |_|    |_|  \_\______||______|

  老佛爷已经付过钱了

"@ -ForegroundColor Cyan
    Write-Host "                  Powered by 慈禧`n" -ForegroundColor DarkGray
}

function Qing_Huanjing([string]$zuoyongyu, [array]$chanpin_liebiao)
{
    $xiaoxi = Kan_Hua "processing_env_vars"
    Han_Hua ("`n" + ($xiaoxi -f $zuoyongyu))

    foreach ($chanpin in $chanpin_liebiao)
    {
        $daxie_jian = "$($chanpin.ming.ToUpper())_VM_OPTIONS"
        $daxie_zhi = [Environment]::GetEnvironmentVariable($daxie_jian, $zuoyongyu)
        $xiaoxi = Kan_Hua "checking_env"
        Di_Gu $xiaoxi $zuoyongyu $daxie_jian $daxie_zhi

        if (-not [string]::IsNullOrEmpty($daxie_zhi))
        {
            $xiaoxi = Kan_Hua "deleting_env"
            Han_Hua ($xiaoxi -f $zuoyongyu, $chanpin.ming)
            [Environment]::SetEnvironmentVariable($daxie_jian, $null, $zuoyongyu)
        }
    }
}

function Kai_Changzi
{
    try
    {
        if (Test-Path -Path $script:gongzuo_lu)
        {
            Remove-Item -Path $script:gongzuo_lu -Recurse -Force -ErrorAction Stop
        }
        New-Item -Path $script:gongzuo_lu -ItemType Directory -Force | Out-Null
        New-Item -Path $script:peizhi_lu -ItemType Directory -Force | Out-Null
        New-Item -Path $script:chajian_lu -ItemType Directory -Force | Out-Null
    }
    catch
    {
        Ma (Kan_Hua "file_in_use")
        Shan_Ren
    }
}

function Ban_Huo
{
    $huowu = @(
        @{ laiyuan = Join-Path $script:xiazai_lu "ja-netfilter.jar"; mubiao = $script:netfilter_jar },
        @{ laiyuan = Join-Path $script:xiazai_lu "config/dns.conf"; mubiao = [IO.Path]::Combine($script:peizhi_lu, "dns.conf") },
        @{ laiyuan = Join-Path $script:xiazai_lu "config/env.conf"; mubiao = [IO.Path]::Combine($script:peizhi_lu, "env.conf") },
        @{ laiyuan = Join-Path $script:xiazai_lu "config/native.conf"; mubiao = [IO.Path]::Combine($script:peizhi_lu, "native.conf") },
        @{ laiyuan = Join-Path $script:xiazai_lu "config/power.conf"; mubiao = [IO.Path]::Combine($script:peizhi_lu, "power.conf") },
        @{ laiyuan = Join-Path $script:xiazai_lu "config/url.conf"; mubiao = [IO.Path]::Combine($script:peizhi_lu, "url.conf") },

        @{ laiyuan = Join-Path $script:xiazai_lu "plugins/dns.jar"; mubiao = [IO.Path]::Combine($script:chajian_lu, "dns.jar") },
        @{ laiyuan = Join-Path $script:xiazai_lu "plugins/env.jar"; mubiao = [IO.Path]::Combine($script:chajian_lu, "env.jar") },
        @{ laiyuan = Join-Path $script:xiazai_lu "plugins/native.jar"; mubiao = [IO.Path]::Combine($script:chajian_lu, "native.jar") },
        @{ laiyuan = Join-Path $script:xiazai_lu "plugins/power.jar"; mubiao = [IO.Path]::Combine($script:chajian_lu, "power.jar") },
        @{ laiyuan = Join-Path $script:xiazai_lu "plugins/url.jar"; mubiao = [IO.Path]::Combine($script:chajian_lu, "url.jar") },
        @{ laiyuan = Join-Path $script:xiazai_lu "plugins/hideme.jar"; mubiao = [IO.Path]::Combine($script:chajian_lu, "hideme.jar") },
        @{ laiyuan = Join-Path $script:xiazai_lu "plugins/privacy.jar"; mubiao = [IO.Path]::Combine($script:chajian_lu, "privacy.jar") }
    )

    $zongshu = $huowu.Count
    $dangqian = 0

    foreach ($huo in $huowu)
    {
        $dangqian++
        $baifenbi = [math]::Round(($dangqian / $zongshu) * 100, 2)
        $tiao_chang = 30
        $yitian = [math]::Floor($baifenbi / (100 / $tiao_chang))
        $jindu_tiao = "[" + ("#" * $yitian) + ("." * ($tiao_chang - $yitian)) + "]"

        Hua_Tiao -xiaoxi (Kan_Hua "configuring_ja_netfilter") -jindu_tiao $jindu_tiao -baifenbi $baifenbi -yanse Green

        try
        {
            Copy-Item -Path $huo.laiyuan -Destination $huo.mubiao -Force

            if ($huo.laiyuan.Contains(".jar"))
            {
                $neirong = [System.IO.File]::ReadAllBytes($huo.mubiao)
                $sha1_zhi = [BitConverter]::ToString([Security.Cryptography.SHA1]::Create().ComputeHash($neirong))
                $xiaoxi = Kan_Hua "sha1_info"
                Di_Gu ($xiaoxi -f $huo.laiyuan, $sha1_zhi)
            }
        }
        catch
        {
            $xiaoxi = Kan_Hua "download_failed"
            Ma ($xiaoxi -f $huo.laiyuan)
            $xiaoxi = Kan_Hua "request_fail"
            Di_Gu ($xiaoxi -f $_.Exception.Message)
            Shan_Ren
        }
    }
}

function Che_Peizhi([string]$wenjian_lu)
{
    $hang_lie = Get-Content -Path $wenjian_lu -Encoding UTF8 -ErrorAction SilentlyContinue
    $guolv_hou = $hang_lie | Where-Object {
        -not $script:zhengze.IsMatch($_)
    }
    Set-Content -Path $wenjian_lu -Value $guolv_hou -Force
    $xiaoxi = Kan_Hua "cleaning_vmoptions"
    Di_Gu ($xiaoxi -f $wenjian_lu)
}

function Jia_Peizhi([string]$wenjian_lu)
{
    if (Test-Path -Path $wenjian_lu)
    {
        Add-Content -Path $wenjian_lu -Value $script:vm_neirong -Force
        $xiaoxi = Kan_Hua "updating_vmoptions"
        Di_Gu ($xiaoxi -f $wenjian_lu)
    }
}

function Zheng_Chajian([string]$chajian_wenjian)
{
    if ([string]::IsNullOrWhiteSpace($chajian_wenjian))
    {
        $xiaoxi = Kan_Hua "file_path_empty"
        Di_Gu ($xiaoxi -f $chajian_wenjian)
        return
    }

    if (-not (Test-Path -Path $chajian_wenjian))
    {
        $xiaoxi = Kan_Hua "file_not_exist_skip"
        Di_Gu ($xiaoxi -f $chajian_wenjian)
        return
    }

    try
    {
        $neirong = Get-Content -Path $chajian_wenjian -Encoding UTF8 -ErrorAction Stop

        $guolv_neirong = $neirong | Where-Object { $_ -ne "com.intellij.modules.ultimate" }

        if ($neirong.Count -ne $guolv_neirong.Count)
        {
            Set-Content -Path $chajian_wenjian -Value $guolv_neirong -Encoding UTF8 -Force
            $xiaoxi = Kan_Hua "processing_disabled_plugins"
            Di_Gu ($xiaoxi -f $chajian_wenjian)
        }
    }
    catch
    {
        $xiaoxi = Kan_Hua "error_processing_plugins"
        Rang ($xiaoxi -f $_)
    }
}

function Pei_Miyao([hashtable]$chanpin, [string]$chanpin_quanming)
{
    $xiaoxi = Kan_Hua "processing_config"
    Di_Gu ($xiaoxi -f $chanpin.ming, $chanpin_quanming, "")

    $chanpin_mulu = Join-Path -Path $script:manyou_jb -ChildPath $chanpin_quanming

    if (-not (Test-Path -Path $chanpin_mulu))
    {
        $xiaoxi = Kan_Hua "manual_activation_required"
        Rang ($xiaoxi -f $chanpin_quanming)
        return
    }

    $vm_wenjian = Join-Path -Path $chanpin_mulu "$($chanpin.ming)64.exe.vmoptions"
    $miyao_wenjian = Join-Path -Path $chanpin_mulu "$($chanpin.ming).key"
    $chajian_wenjian = Join-Path -Path $chanpin_mulu "disabled_plugins.txt"

    if (Test-Path -Path $vm_wenjian)
    {
        $xiaoxi = Kan_Hua "config_exists_cleaning"
        Di_Gu ($xiaoxi -f $chanpin_quanming)
        Che_Peizhi -wenjian_lu $vm_wenjian
    }

    if (Test-Path -Path $miyao_wenjian)
    {
        $xiaoxi = Kan_Hua "key_exists_cleaning"
        Di_Gu ($xiaoxi)
        Remove-Item -Path $miyao_wenjian -Force
    }

    $xuke_laiyuan = Join-Path $script:xuke_lu "$($chanpin.ming).key"
    $xiaoxi = Kan_Hua "requesting_key"
    Di_Gu ($xiaoxi -f $xuke_laiyuan, $chanpin.ming, $miyao_wenjian)
    try
    {
        Copy-Item -Path $xuke_laiyuan -Destination $miyao_wenjian -Force
        $xiaoxi = Kan_Hua "writing_key"
        Di_Gu ($xiaoxi -f $miyao_wenjian)
        Zheng_Chajian($chajian_wenjian)
        $xiaoxi = Kan_Hua "activation_success"
        Hao ($xiaoxi -f $chanpin_quanming)
    }
    catch
    {
        $xiaoxi = Kan_Hua "manual_activation_required"
        Rang ($xiaoxi -f $chanpin_quanming)
        $xiaoxi = Kan_Hua "request_failed"
        Di_Gu ($xiaoxi -f $chanpin_quanming, $_.Exception.Message)
    }
}

function Zheng_Vm
{
    Han_Hua (Kan_Hua "processing_configs")

    if (!(Test-Path -Path $script:bendi_jb))
    {
        $xiaoxi = Kan_Hua "not_found_dir"
        Ma ($xiaoxi -f $script:bendi_jb)
        Shan_Ren
    }
    $bendi_chanpin = Get-ChildItem -Path $script:bendi_jb -Directory

    foreach ($mulu in $bendi_chanpin)
    {
        $chanpin = Pan_Chanpin -mulu_ming $mulu.Name
        if ($null -eq $chanpin)
        {
            continue
        }

        $xiaoxi = Kan_Hua "processing_product"
        Han_Hua ($xiaoxi -f $mulu)

        $home_wenjian = Join-Path -Path $mulu.FullName ".home"
        if (-not (Test-Path -Path $home_wenjian))
        {
            $xiaoxi = Kan_Hua "not_found_home"
            Rang ($xiaoxi -f $home_wenjian)
            continue
        }
        $xiaoxi = Kan_Hua "found_home_file"
        Di_Gu ($xiaoxi -f $home_wenjian)
        $home_neirong = Get-Content -Path $home_wenjian -Encoding UTF8
        if (-not (Test-Path -Path $home_neirong))
        {
            $xiaoxi = Kan_Hua "path_not_exist"
            Rang ($xiaoxi -f $home_neirong)
            continue
        }
        $xiaoxi = Kan_Hua "read_home_content"
        Di_Gu ($xiaoxi -f $home_neirong)
        $zhenshi_mulu = Join-Path -Path $home_neirong "bin"
        if (-not (Test-Path -Path $zhenshi_mulu))
        {
            $xiaoxi = Kan_Hua "not_found_bin"
            Rang ($xiaoxi -f $zhenshi_mulu)
            continue
        }
        $xiaoxi = Kan_Hua "found_bin_dir"
        Di_Gu ($xiaoxi -f $zhenshi_mulu)
        $vm_wenjian_lie = Get-ChildItem -Path $zhenshi_mulu -Filter "*.vmoptions" -Recurse
        foreach ($vm_wenjian in $vm_wenjian_lie)
        {
            Che_Peizhi -wenjian_lu $vm_wenjian.FullName
            Jia_Peizhi -wenjian_lu $vm_wenjian.FullName
        }

        Pei_Miyao -chanpin $chanpin -chanpin_quanming $mulu.Name
    }
}

function Pan_Chanpin([string]$mulu_ming)
{
    foreach ($chanpin in $script:chanpin_lie)
    {
        if ($mulu_ming.ToLower().Contains($chanpin.ming))
        {
            return $chanpin
        }
    }
    return $null
}

function Kai_Gan
{
    Liang_Paizi

    Write-Host @"

========================================
       用  户  协  议  /  EULA
========================================

本项目为免费工具，作者不从中获取任何金钱以及其他的各种形式的利益。
如果你为获取本项目支付了任何费用，说明你已经被骗，

本项目仅供学习、研究计算机软件技术之用，
严禁用于任何商业用途或盈利性目的。
使用本工具产生的任何后果由使用者自行承担，
作者不承担任何法律责任。

========================================
        使  用  者  义  务
========================================

1. 你必须在运行本工具后的 24 小时内，
   删除所有经本工具处理过的 JetBrains 相关程序及配置。

2. 如未在规定时间内删除，视为使用者自愿承担
   由此产生的全部法律责任及后果，与作者无关。

3. 商业用户请购买 JetBrains 官方正版授权：
   https://www.jetbrains.com

========================================

如果你理解并同意上述全部条款，请在下方输入：
  我已知晓上述并且同意

输入其他任何内容将退出程序。

"@ -ForegroundColor Yellow

    $tongyi = Read-Host
    if ($tongyi -ne "我已知晓上述并且同意")
    {
        Write-Host "`n你未同意上述条款，程序退出。`n" -ForegroundColor Red
        $null = Read-Host
        exit 0
    }

    Write-Host "`n理解万岁`n" -ForegroundColor Green
    Start-Sleep -s 1

    if (-not ([Security.Principal.WindowsPrincipal][Security.Principal.WindowsIdentity]::GetCurrent()).IsInRole([Security.Principal.WindowsBuiltInRole]"Administrator"))
    {
        Rang (Kan_Hua "admin_request")
        $null = Read-Host
        Start-Process powershell.exe -ArgumentList "-File `"$PSCommandPath`"" -Verb RunAs
        exit -1
    }


    Rang (Kan_Hua "close_products")
    $null = Read-Host

    $yonghu_lu = [Environment]::GetEnvironmentVariable("USERPROFILE")
    $gonggong_lu = [Environment]::GetEnvironmentVariable("PUBLIC")
    $script:yuan_lu = Split-Path -Parent $PSScriptRoot
    $script:xiazai_lu = Join-Path $script:yuan_lu "ja-netfilter"
    $script:xuke_lu = Join-Path $script:yuan_lu "licenses"

    $script:gongzuo_lu = "$gonggong_lu\.jb_run\"
    $script:peizhi_lu = "$script:gongzuo_lu\config\"
    $script:chajian_lu = "$script:gongzuo_lu\plugins\"
    $script:netfilter_jar = Join-Path -Path $script:gongzuo_lu "ja-netfilter.jar"
    $script:bendi_jb = Join-Path -Path $yonghu_lu -ChildPath "AppData\Local\JetBrains\"
    $script:manyou_jb = Join-Path -Path $yonghu_lu -ChildPath "AppData\Roaming\JetBrains\"

    $moshi = '^-javaagent:.*[/\\]*\.jar.*'
    $script:zhengze = New-Object System.Text.RegularExpressions.Regex $moshi, ([System.Text.RegularExpressions.RegexOptions]::IgnoreCase -bor [System.Text.RegularExpressions.RegexOptions]::Compiled)

    $script:vm_neirong = @(
        "-javaagent:$($script:netfilter_jar.Replace("\", "/") )"
    )

    $script:chanpin_lie = @(
        @{ ming = "idea";      daima = "II,PCWMP,PSI" }
        @{ ming = "clion";     daima = "CL,PSI,PCWMP" }
        @{ ming = "phpstorm";  daima = "PS,PCWMP,PSI" }
        @{ ming = "goland";    daima = "GO,PSI,PCWMP" }
        @{ ming = "pycharm";   daima = "PC,PSI,PCWMP" }
        @{ ming = "webstorm";  daima = "WS,PCWMP,PSI" }
        @{ ming = "rider";     daima = "RD,PDB,PSI,PCWMP" }
        @{ ming = "datagrip";  daima = "DB,PSI,PDB" }
        @{ ming = "rubymine";  daima = "RM,PCWMP,PSI" }
        @{ ming = "appcode";   daima = "AC,PCWMP,PSI" }
        @{ ming = "dataspell"; daima = "DS,PSI,PDB,PCWMP" }
        @{ ming = "rustrover"; daima = "RR,PSI,PCWP" }
    )

    Han_Hua (Kan_Hua "processing")

    Qing_Huanjing -zuoyongyu "User" -chanpin_liebiao $script:chanpin_lie
    Qing_Huanjing -zuoyongyu "Machine" -chanpin_liebiao $script:chanpin_lie

    Kai_Changzi
    Ban_Huo
    Zheng_Vm

    Han_Hua (Kan_Hua "processing_completed")
    $zuozhe = "慈禧"
    Write-Host "`n========================================" -ForegroundColor Cyan
    Write-Host "  Powered by $zuozhe | FREE FOREVER" -ForegroundColor Green
    Write-Host "========================================`n" -ForegroundColor Cyan
    Start-Sleep -s 2
    $null = Read-Host
}

Kai_Gan


#老佛爷付过钱了，咱们不需要付钱了
#慈禧太后老人家早就替你把 JetBrains 的账给结了